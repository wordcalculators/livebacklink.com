<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing rules first, so that the app and ENVIRONMENT
// can override them if needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('PublicController');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

/**
 * --------------------------------------------------------------------
 * Route Definitions (LiveBacklink.com REST API v2.0)
 * Subdomain: api.livebacklink.com
 * --------------------------------------------------------------------
 */

// Global CORS preflight handler
$routes->options('(:any)', 'PublicController::options');

$routes->group('api', function($routes) {

    // 1. PUBLIC ENDPOINTS (No authentication required)
    $routes->get('packages', 'PublicController::getPackages');
    $routes->get('packages/(:segment)', 'PublicController::getPackageBySlug/$1');
    $routes->get('samples', 'PublicController::getSamples');
    $routes->get('notifications/live', 'PublicController::getLiveNotifications');
    $routes->post('contact', 'PublicController::submitContact');
    $routes->get('health', 'PublicController::healthCheck');
    $routes->get('update-database', 'PublicController::updateDatabase');

    // 2. AUTHENTICATION ENDPOINTS
    $routes->group('auth', function($routes) {
        $routes->post('register', 'Auth::register');
        $routes->post('login', 'Auth::login');
        $routes->post('logout', 'Auth::logout');
        $routes->post('forgot-password', 'Auth::forgotPassword');
        $routes->post('reset-password', 'Auth::resetPassword');
        $routes->get('me', 'Auth::me', ['filter' => 'jwt_auth']);
    });

    // 3. CLIENT PORTAL ENDPOINTS (Requires client or admin role)
    $routes->group('client', ['filter' => 'jwt_auth'], function($routes) {
        $routes->get('dashboard', 'Client::dashboard');
        $routes->get('orders', 'Client::orders');
        $routes->post('orders', 'Client::orders');
        $routes->get('orders/(:num)', 'Client::orderDetail/$1');
        $routes->put('orders/(:num)', 'Client::updateOrderDetails/$1');
        $routes->post('payments/upload/(:num)', 'Client::uploadPaymentProof/$1');
        $routes->get('reports/(:num)', 'Client::orderReport/$1');
        $routes->get('reports', 'Client::allReports');
        $routes->get('payments', 'Client::payments');
        $routes->get('profile', 'Client::getProfile');
        $routes->put('profile', 'Client::updateProfile');
        $routes->put('profile/password', 'Client::changePassword');
    });

    // 4. ADMIN PANEL ENDPOINTS (Strictly requires admin role)
    $routes->group('admin', ['filter' => 'jwt_admin_auth'], function($routes) {
        $routes->get('dashboard', 'Admin::dashboard');
        $routes->get('orders', 'Admin::orders');
        $routes->get('orders/(:num)', 'Admin::orderDetail/$1');
        $routes->put('orders/(:num)', 'Admin::updateOrderDetails/$1');
        
        // Section 8: Master Google Sheet Report (ONE URL per order)
        $routes->post('orders/(:num)/report/save', 'Admin::saveMasterReport/$1');
        $routes->post('orders/(:num)/phases/(:num)/complete', 'Admin::completePhase/$1/$2');

        // Section 7: Manual Payment Review
        $routes->get('payments', 'Admin::payments');
        $routes->post('payments/(:num)/verify', 'Admin::verifyPayment/$1');
        $routes->post('payments/(:num)/reject', 'Admin::rejectPayment/$1');

        // Client Management
        $routes->get('clients', 'Admin::clients');
        $routes->get('clients/(:num)', 'Admin::clientDetail/$1');

        // Packages Management
        $routes->get('packages', 'Admin::packages');
        $routes->post('packages', 'Admin::createPackage');
        $routes->put('packages/(:num)', 'Admin::updatePackage/$1');

        // Sample Links Management
        $routes->get('samples', 'Admin::samples');
        $routes->post('samples', 'Admin::createSample');
        $routes->put('samples/(:num)', 'Admin::updateSample/$1');
        $routes->delete('samples/(:num)', 'Admin::deleteSample/$1');

        // Social Proof Notifications
        $routes->get('notifications', 'Admin::notifications');
        $routes->post('notifications', 'Admin::createNotification');

        // System Settings (Bank, SMTP, SEO, Maintenance)
        $routes->get('settings', 'Admin::getSettings');
        $routes->put('settings', 'Admin::updateSettings');

        // Logs & Exports
        $routes->get('logs', 'Admin::activityLogs');
        $routes->get('logs/logins', 'Admin::loginLogs');
        $routes->get('orders/export', 'Admin::exportOrdersCsv');
        $routes->get('payments/export', 'Admin::exportPaymentsCsv');
    });
});
