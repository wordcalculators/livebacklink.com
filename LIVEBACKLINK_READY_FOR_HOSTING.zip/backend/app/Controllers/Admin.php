<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Admin extends ResourceController
{
    protected $format = 'json';

    private function getAdminId()
    {
        return $this->request->header('X-User-Id') ? (int)$this->request->header('X-User-Id')->getValue() : null;
    }

    /**
     * GET /api/admin/dashboard
     */
    public function dashboard()
    {
        $db = \Config\Database::connect();

        $totalRevenue = $db->table('orders')
            ->whereIn('status', ['in_progress', 'completed'])
            ->selectSum('amount')
            ->get()
            ->getRowArray()['amount'] ?? 0;

        $totalOrders = $db->table('orders')->countAllResults();
        $pendingPayments = $db->table('payment_requests')->where('status', 'pending')->countAllResults();
        $totalClients = $db->table('users')->where('role', 'client')->countAllResults();

        $recentOrders = $db->table('orders')
            ->join('users', 'users.id = orders.user_id')
            ->select('orders.*, users.name as client_name, users.email as client_email')
            ->orderBy('orders.id', 'DESC')
            ->limit(5)
            ->get()
            ->getResultArray();

        $activityLogs = $db->table('activity_logs')
            ->orderBy('id', 'DESC')
            ->limit(10)
            ->get()
            ->getResultArray();

        return $this->respond([
            'success' => true,
            'kpis' => [
                'total_revenue'       => (float)$totalRevenue,
                'total_orders'        => (int)$totalOrders,
                'pending_payments'    => (int)$pendingPayments,
                'total_clients'       => (int)$totalClients,
            ],
            'recent_orders' => $recentOrders,
            'activity_logs' => $activityLogs,
        ]);
    }

    /**
     * GET /api/admin/orders
     */
    public function orders()
    {
        $db = \Config\Database::connect();
        $orders = $db->table('orders')
            ->join('users', 'users.id = orders.user_id')
            ->select('orders.*, users.name as client_name, users.email as client_email')
            ->orderBy('orders.id', 'DESC')
            ->get()
            ->getResultArray();

        foreach ($orders as &$order) {
            $order['report'] = $db->table('order_reports')
                ->where('order_id', $order['id'])
                ->get()
                ->getRowArray();
        }

        return $this->respond(['success' => true, 'orders' => $orders]);
    }

    /**
     * PUT /api/admin/orders/{id}
     */
    public function updateOrderDetails($id = null)
    {
        $adminId = $this->getAdminId();
        $db = \Config\Database::connect();

        $order = $db->table('orders')->where('id', $id)->get()->getRowArray();

        if (!$order) {
            return $this->failNotFound('Order not found.');
        }

        $input = $this->request->getJSON(true) ?: $this->request->getRawInput();
        
        $updateData = [
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Process fields
        $fields = [
            'business_name', 'business_address', 'business_phone', 'business_email',
            'business_category', 'business_photos_link', 'target_country',
            'short_description', 'short_description_200', 'target_url', 'anchor_text', 'special_notes',
            'business_logo_path'
        ];

        foreach ($fields as $f) {
            if (isset($input[$f])) {
                $updateData[$f] = trim(esc($input[$f]));
            }
        }

        $db->table('orders')->where('id', $id)->update($updateData);

        // Add activity log
        $db->table('activity_logs')->insert([
            'user_id'     => $adminId,
            'role'        => 'admin',
            'action'      => 'ORDER_UPDATED',
            'description' => "Order details updated by admin for Order ID {$id}",
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->respond([
            'success' => true,
            'message' => 'Order details updated successfully by admin.'
        ]);
    }

    /**
     * GET /api/admin/orders/{id}
     */
    public function orderDetail($id = null)
    {
        $db = \Config\Database::connect();
        $order = $db->table('orders')
            ->join('users', 'users.id = orders.user_id')
            ->select('orders.*, users.name as client_name, users.email as client_email, users.company, users.phone')
            ->where('orders.id', $id)
            ->get()
            ->getRowArray();

        if (!$order) {
            return $this->failNotFound('Order not found.');
        }

        $order['phases'] = $db->table('order_phases')
            ->where('order_id', $id)
            ->orderBy('phase_number', 'ASC')
            ->get()
            ->getResultArray();

        $order['payment'] = $db->table('payment_requests')
            ->where('order_id', $id)
            ->get()
            ->getRowArray();

        // Section 8: Single Master Report
        $order['report'] = $db->table('order_reports')
            ->where('order_id', $id)
            ->get()
            ->getRowArray();

        return $this->respond(['success' => true, 'order' => $order]);
    }

    /**
     * POST /api/admin/orders/{id}/report/save
     * Section 8: ONE ORDER = ONE MASTER GOOGLE SHEET URL
     */
    public function saveMasterReport($id = null)
    {
        $adminId = $this->getAdminId();
        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $url = trim($input['spreadsheet_url'] ?? '');

        // Validation per Section 8: Must start with https://docs.google.com/spreadsheets/
        if (!str_starts_with($url, 'https://docs.google.com/spreadsheets/')) {
            return $this->fail('Invalid Google Sheet URL. URL must start with https://docs.google.com/spreadsheets/', 400);
        }

        $db = \Config\Database::connect();
        $order = $db->table('orders')->where('id', $id)->get()->getRowArray();
        if (!$order) {
            return $this->failNotFound('Order not found.');
        }

        $existing = $db->table('order_reports')->where('order_id', $id)->get()->getRowArray();

        $reportData = [
            'order_id'        => $id,
            'spreadsheet_url' => $url,
            'title'           => trim(esc($input['title'] ?? ($order['package_name'] . ' Master Delivery Report'))),
            'description'     => trim(esc($input['description'] ?? ('Live Master Google Sheet for Order #' . $order['invoice_no']))),
            'is_visible'      => !empty($input['is_visible']),
            'last_updated_at' => date('Y-m-d H:i:s'),
            'added_by'        => $adminId,
        ];

        if ($existing) {
            $db->table('order_reports')->where('order_id', $id)->update($reportData);
        } else {
            $reportData['created_at'] = date('Y-m-d H:i:s');
            $db->table('order_reports')->insert($reportData);
        }

        // Activity log
        $db->table('activity_logs')->insert([
            'user_id'     => $adminId,
            'role'        => 'admin',
            'action'      => 'MASTER_REPORT_CONFIGURED',
            'description' => "Configured single Master Google Sheet for order #{$order['invoice_no']}",
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->respond([
            'success' => true,
            'message' => 'Master Google Sheet report configured successfully.',
            'report'  => $reportData,
        ]);
    }

    /**
     * POST /api/admin/orders/{id}/phases/{pid}/complete
     * Section 8 & 9: Mark phase complete, prompt link count, update master report
     */
    public function completePhase($id = null, $phaseId = null)
    {
        $adminId = $this->getAdminId();
        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $linksDelivered = (int)($input['links_delivered'] ?? 0);

        if ($linksDelivered <= 0) {
            return $this->fail('Please enter a valid count of delivered links for this phase.', 400);
        }

        $db = \Config\Database::connect();
        $phase = $db->table('order_phases')->where('phase_number', $phaseId)->where('order_id', $id)->get()->getRowArray();
        if (!$phase) {
            return $this->failNotFound('Order phase not found.');
        }

        if ($phase['status'] === 'completed') {
            return $this->fail('This order phase has already been completed.', 409);
        }

        if ((int)$phase['phase_number'] > 1) {
            $previous = $db->table('order_phases')
                ->where('order_id', $id)
                ->where('phase_number', (int)$phase['phase_number'] - 1)
                ->get()->getRowArray();
            if ($previous && $previous['status'] !== 'completed') {
                return $this->fail('Order phases must be completed in sequence.', 409);
            }
        }

        $order = $db->table('orders')->where('id', $id)->get()->getRowArray();

        // 1. Update order phase
        $db->table('order_phases')->where('id', $phaseId)->update([
            'delivered_links'       => $linksDelivered,
            'links_delivered_count' => $linksDelivered,
            'status'                => 'completed',
            'completed_at'          => date('Y-m-d H:i:s'),
            'notification_sent'     => true,
        ]);

        // 2. Update order report total links and timestamp
        $report = $db->table('order_reports')->where('order_id', $id)->get()->getRowArray();
        if ($report) {
            $db->table('order_reports')->where('order_id', $id)->update([
                'total_links'     => $report['total_links'] + $linksDelivered,
                'last_updated_at' => date('Y-m-d H:i:s'),
                'is_visible'      => true,
            ]);
        }

        // 3. Increment completed phases on order
        $newCompletedPhases = $order['completed_phases'] + 1;
        $orderStatus = ($newCompletedPhases >= $order['total_phases']) ? 'completed' : 'in_progress';

        $db->table('orders')->where('id', $id)->update([
            'completed_phases' => $newCompletedPhases,
            'status'           => $orderStatus,
            'updated_at'       => date('Y-m-d H:i:s'),
        ]);

        // 4. Activate next phase if exists
        $nextPhase = $db->table('order_phases')
            ->where('order_id', $id)
            ->where('phase_number', $phase['phase_number'] + 1)
            ->get()
            ->getRowArray();

        if ($nextPhase && $nextPhase['status'] === 'pending') {
            $db->table('order_phases')->where('id', $nextPhase['id'])->update(['status' => 'in_progress']);
        }

        // 5. Activity log
        $db->table('activity_logs')->insert([
            'user_id'     => $adminId,
            'role'        => 'admin',
            'action'      => 'PHASE_COMPLETED',
            'description' => "Marked {$phase['week_label']} completed for order #{$order['invoice_no']} (+{$linksDelivered} links delivered)",
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->respond([
            'success' => true,
            'message' => "{$phase['week_label']} marked delivered with {$linksDelivered} links recorded.",
            'completed_phases' => $newCompletedPhases,
            'order_status'     => $orderStatus,
        ]);
    }

    /**
     * GET /api/admin/payments
     */
    public function payments()
    {
        $db = \Config\Database::connect();
        $payments = $db->table('payment_requests')
            ->join('orders', 'orders.id = payment_requests.order_id')
            ->join('users', 'users.id = payment_requests.user_id')
            ->select('payment_requests.*, orders.invoice_no, orders.amount, orders.package_name, users.name as client_name, users.email as client_email')
            ->orderBy('payment_requests.id', 'DESC')
            ->get()
            ->getResultArray();

        return $this->respond(['success' => true, 'payments' => $payments]);
    }

    /**
     * POST /api/admin/payments/{id}/verify
     */
    public function verifyPayment($id = null)
    {
        $adminId = $this->getAdminId();
        $db = \Config\Database::connect();

        $payment = $db->table('payment_requests')->where('id', $id)->get()->getRowArray();
        if (!$payment) {
            return $this->failNotFound('Payment request not found.');
        }

        $order = $db->table('orders')->where('id', $payment['order_id'])->get()->getRowArray();
        if (!$order) {
            return $this->failNotFound('Order not found.');
        }
        if ($payment['status'] !== 'pending') {
            return $this->fail('This payment request has already been reviewed.', 409);
        }

        $db->transStart();
        $db->table('payment_requests')->where('id', $id)->update([
            'status'      => 'approved',
            'verified_at' => date('Y-m-d H:i:s'),
            'verified_by' => $adminId,
        ]);

        // Activate order and start Phase 1 (in_progress)
        $db->table('orders')->where('id', $payment['order_id'])->update([
            'status'     => 'in_progress',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        // Start Phase 1
        $db->table('order_phases')
            ->where('order_id', $payment['order_id'])
            ->where('phase_number', 1)
            ->update(['status' => 'in_progress']);

        // Activity log
        $db->table('activity_logs')->insert([
            'user_id'     => $adminId,
            'role'        => 'admin',
            'action'      => 'PAYMENT_VERIFIED',
            'description' => "Approved wire payment for order #{$order['invoice_no']} ($" . number_format($order['amount'], 2) . ")",
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        $db->transComplete();

        if ($db->transStatus() === false) {
            return $this->failServerError('Payment approval could not be committed.');
        }

        return $this->respond([
            'success' => true,
            'message' => "Payment verified for order #{$order['invoice_no']}. Campaign is now In Progress.",
        ]);
    }

    /**
     * POST /api/admin/payments/{id}/reject
     */
    public function rejectPayment($id = null)
    {
        $adminId = $this->getAdminId();
        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $reason = trim($input['reason'] ?? '');

        if (empty($reason)) {
            return $this->fail('Rejection reason is required.', 400);
        }

        $db = \Config\Database::connect();
        $payment = $db->table('payment_requests')->where('id', $id)->get()->getRowArray();
        if (!$payment) {
            return $this->failNotFound('Payment request not found.');
        }

        $order = $db->table('orders')->where('id', $payment['order_id'])->get()->getRowArray();
        if (!$order) {
            return $this->failNotFound('Order not found.');
        }
        if ($payment['status'] !== 'pending') {
            return $this->fail('This payment request has already been reviewed.', 409);
        }

        $db->transStart();
        $db->table('payment_requests')->where('id', $id)->update([
            'status'     => 'rejected',
            'admin_note' => esc($reason),
        ]);

        $db->table('orders')->where('id', $payment['order_id'])->update([
            'status'     => 'pending_payment',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        $db->table('activity_logs')->insert([
            'user_id' => $adminId,
            'role' => 'admin',
            'action' => 'PAYMENT_REJECTED',
            'description' => "Rejected payment for order #{$order['invoice_no']}",
            'ip_address' => $this->request->getIPAddress(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        $db->transComplete();

        if ($db->transStatus() === false) {
            return $this->failServerError('Payment rejection could not be committed.');
        }

        return $this->respond([
            'success' => true,
            'message' => "Payment rejected for order #{$order['invoice_no']}.",
        ]);
    }

    /**
     * GET /api/admin/settings
     * PUT /api/admin/settings
     */
    public function getSettings()
    {
        $db = \Config\Database::connect();
        $settings = $db->table('settings')->get()->getResultArray();
        $keyed = [];
        foreach ($settings as $s) {
            $keyed[$s['key']] = $s['value'];
        }
        return $this->respond(['success' => true, 'settings' => $keyed]);
    }

    public function updateSettings()
    {
        $adminId = $this->getAdminId();
        $input = $this->request->getJSON(true) ?: $this->request->getRawInput();
        $db = \Config\Database::connect();

        foreach ($input as $key => $value) {
            $db->table('settings')
                ->where('key', $key)
                ->update([
                    'value'      => esc((string)$value),
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
        }

        // Activity log
        $db->table('activity_logs')->insert([
            'user_id'     => $adminId,
            'role'        => 'admin',
            'action'      => 'SETTINGS_UPDATED',
            'description' => 'System settings updated by administrator',
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->respond(['success' => true, 'message' => 'Settings updated successfully']);
    }

    /**
     * GET /api/admin/clients
     */
    public function clients()
    {
        $db = \Config\Database::connect();
        $clients = $db->table('users')
            ->where('role', 'client')
            ->orderBy('id', 'DESC')
            ->get()
            ->getResultArray();

        foreach ($clients as &$client) {
            unset($client['password_hash']);
            $client['orders_count'] = $db->table('orders')->where('user_id', $client['id'])->countAllResults();
        }

        return $this->respond($clients);
    }

    public function clientDetail($id = null)
    {
        $db = \Config\Database::connect();
        $client = $db->table('users')->where('id', $id)->where('role', 'client')->get()->getRowArray();
        if (!$client) return $this->failNotFound('Client not found');
        unset($client['password_hash']);
        $orders = $db->table('orders')->where('user_id', $id)->get()->getResultArray();
        return $this->respond(['success' => true, 'client' => $client, 'orders' => $orders]);
    }

    public function packages()
    {
        $db = \Config\Database::connect();
        $packages = $db->table('packages')->orderBy('display_order', 'ASC')->get()->getResultArray();
        return $this->respond(['success' => true, 'packages' => $packages]);
    }

    public function createPackage()
    {
        return $this->fail('Not fully implemented yet.');
    }

    public function updatePackage($id = null)
    {
        return $this->fail('Not fully implemented yet.');
    }

    public function samples()
    {
        $db = \Config\Database::connect();
        $samples = $db->table('sample_links')->get()->getResultArray();
        return $this->respond(['success' => true, 'samples' => $samples]);
    }

    public function createSample()
    {
        return $this->fail('Not fully implemented yet.');
    }

    public function updateSample($id = null)
    {
        return $this->fail('Not fully implemented yet.');
    }

    public function deleteSample($id = null)
    {
        return $this->fail('Not fully implemented yet.');
    }

    public function notifications()
    {
        $db = \Config\Database::connect();
        $notifications = $db->table('order_notifications')->get()->getResultArray();
        return $this->respond(['success' => true, 'notifications' => $notifications]);
    }

    public function createNotification()
    {
        return $this->fail('Not fully implemented yet.');
    }

    public function activityLogs()
    {
        $db = \Config\Database::connect();
        $logs = $db->table('activity_logs')->orderBy('id', 'DESC')->get()->getResultArray();
        return $this->respond(['success' => true, 'logs' => $logs]);
    }

    public function loginLogs()
    {
        $db = \Config\Database::connect();
        $logs = $db->table('login_logs')->orderBy('id', 'DESC')->get()->getResultArray();
        return $this->respond(['success' => true, 'logs' => $logs]);
    }

    public function exportOrdersCsv()
    {
        return $this->fail('Not fully implemented yet.');
    }

    public function exportPaymentsCsv()
    {
        return $this->fail('Not fully implemented yet.');
    }

}
