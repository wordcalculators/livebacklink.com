<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\HTTP\ResponseInterface;

class Auth extends ResourceController
{
    protected $format = 'json';

    /**
     * POST /api/auth/register
     */
    public function register()
    {
        $db = \Config\Database::connect();
        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'name'     => 'required|min_length[2]|max_length[100]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[8]|regex_match[/^(?=.*[0-9])(?=.*[!@#\$\%\^&\*]).{8,}$/]',
            'company'  => 'permit_empty|max_length[100]',
            'phone'    => 'permit_empty|max_length[30]',
        ];

        if (!$this->validate($rules)) {
            return $this->failValidationErrors($this->validator->getErrors());
        }

        $passwordHash = password_hash($input['password'], PASSWORD_BCRYPT, ['cost' => 10]);

        $userData = [
            'name'           => trim(esc($input['name'])),
            'email'          => strtolower(trim(esc($input['email']))),
            'password_hash'  => $passwordHash,
            'role'           => 'client',
            'status'         => 'active',
            'email_verified' => true, // Auto-verify on self registration
            'company'        => isset($input['company']) ? trim(esc($input['company'])) : null,
            'phone'          => isset($input['phone']) ? trim(esc($input['phone'])) : null,
            'created_at'     => date('Y-m-d H:i:s'),
            'updated_at'     => date('Y-m-d H:i:s'),
        ];

        $db->table('users')->insert($userData);
        $userId = $db->insertID();

        // Issue JWT token
        $token = $this->generateJwt($userId, $userData['email'], $userData['role']);

        // Log activity
        $db->table('activity_logs')->insert([
            'user_id'     => $userId,
            'user_name'   => $userData['name'],
            'role'        => 'client',
            'action'      => 'USER_REGISTERED',
            'description' => 'New client account created: ' . $userData['email'],
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->respondCreated([
            'success' => true,
            'message' => 'Registration successful',
            'token'   => $token,
            'user'    => [
                'id'       => $userId,
                'name'     => $userData['name'],
                'email'    => $userData['email'],
                'role'     => $userData['role'],
                'company'  => $userData['company'],
                'phone'    => $userData['phone'],
            ]
        ]);
    }

    /**
     * POST /api/auth/login
     */
    public function login()
    {
        $db = \Config\Database::connect();
        $ip = $this->request->getIPAddress();
        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        // Rate limiting check (PRD Section 13: 5 failed attempts -> 15 min block)
        $fifteenMinutesAgo = date('Y-m-d H:i:s', strtotime('-15 minutes'));
        $recentFailedAttempts = $db->table('login_logs')
            ->where('ip_address', $ip)
            ->where('status', 'failed')
            ->where('created_at >=', $fifteenMinutesAgo)
            ->countAllResults();

        if ($recentFailedAttempts >= 5) {
            $db->table('login_logs')->insert([
                'email'      => 'rate_limited',
                'ip_address' => $ip,
                'user_agent' => $this->request->getUserAgent()->getAgentString(),
                'status'     => 'blocked',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            return $this->fail('Too many failed login attempts. Please wait 15 minutes before trying again.', 429);
        }

        $email = strtolower(trim($input['email'] ?? ''));
        $password = $input['password'] ?? '';

        if (empty($email) || empty($password)) {
            return $this->fail('Email and password are required.', 400);
        }

        $user = $db->table('users')->where('email', $email)->get()->getRowArray();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            // Log failed attempt
            $db->table('login_logs')->insert([
                'user_id'    => $user['id'] ?? null,
                'email'      => $email,
                'ip_address' => $ip,
                'user_agent' => $this->request->getUserAgent()->getAgentString(),
                'status'     => 'failed',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            return $this->failUnauthorized('Invalid email or password.');
        }

        if ($user['status'] !== 'active') {
            return $this->failForbidden('Your account has been suspended. Please contact support@livebacklink.com.');
        }

        // Log successful login
        $db->table('login_logs')->insert([
            'user_id'    => $user['id'],
            'email'      => $email,
            'ip_address' => $ip,
            'user_agent' => $this->request->getUserAgent()->getAgentString(),
            'status'     => 'success',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $token = $this->generateJwt($user['id'], $user['email'], $user['role']);

        return $this->respond([
            'success' => true,
            'token'   => $token,
            'user'    => [
                'id'       => $user['id'],
                'name'     => $user['name'],
                'email'    => $user['email'],
                'role'     => $user['role'],
                'company'  => $user['company'],
                'phone'    => $user['phone'],
            ]
        ]);
    }

    /**
     * GET /api/auth/me
     */
    public function me()
    {
        $userId = $this->request->header('X-User-Id') ? $this->request->header('X-User-Id')->getValue() : null;
        if (!$userId) {
            return $this->failUnauthorized('Session expired or invalid token.');
        }

        $db = \Config\Database::connect();
        $user = $db->table('users')->where('id', $userId)->get()->getRowArray();

        if (!$user) {
            return $this->failNotFound('User profile not found.');
        }

        return $this->respond([
            'success' => true,
            'user'    => [
                'id'       => $user['id'],
                'name'     => $user['name'],
                'email'    => $user['email'],
                'role'     => $user['role'],
                'company'  => $user['company'],
                'phone'    => $user['phone'],
            ]
        ]);
    }

    /**
     * POST /api/auth/logout
     */
    public function logout()
    {
        return $this->respond(['success' => true, 'message' => 'Logged out successfully']);
    }

    /**
     * POST /api/auth/forgot-password
     */
    public function forgotPassword()
    {
        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $email = strtolower(trim($input['email'] ?? ''));

        $db = \Config\Database::connect();
        $user = $db->table('users')->where('email', $email)->get()->getRowArray();

        // Always return success to prevent email enumeration
        return $this->respond([
            'success' => true,
            'message' => 'If an account exists for this email, password reset instructions have been dispatched.'
        ]);
    }

    /**
     * Generate HMAC SHA256 JWT Token
     */
    private function generateJwt($userId, $email, $role)
    {
        $secret = trim((string) env('JWT_SECRET_KEY', ''));
        if ($secret === '') {
            throw new \RuntimeException('JWT_SECRET_KEY is not configured.');
        }
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $payload = json_encode([
            'iss'  => 'https://api.livebacklink.com',
            'aud'  => 'https://livebacklink.com',
            'iat'  => time(),
            'exp'  => time() + (int)env('JWT_ACCESS_TIME', 1800), // 30 min
            'uid'  => $userId,
            'mail' => $email,
            'role' => $role
        ]);

        $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $secret, true);
        $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

        return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
    }


    public function resetPassword()
    {
        $input = $this->request->getJSON(true) ?: $this->request->getRawInput();
        $token = $input['token'] ?? '';
        $newPassword = $input['password'] ?? '';
        
        if (empty($token) || strlen($newPassword) < 8) {
            return $this->fail('Invalid token or password too short (min 8 chars).', 400);
        }
        
        $db = \Config\Database::connect();
        $user = $db->table('users')->where('reset_token', $token)->get()->getRowArray();
        
        if (!$user || strtotime($user['reset_token_expires']) < time()) {
            return $this->fail('Invalid or expired reset token.', 400);
        }
        
        $db->table('users')->where('id', $user['id'])->update([
            'password_hash' => password_hash($newPassword, PASSWORD_DEFAULT),
            'reset_token' => null,
            'reset_token_expires' => null,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
        
        return $this->respond(['success' => true, 'message' => 'Password reset successfully']);
    }

}
