<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Client extends ResourceController
{
    protected $format = 'json';

    private function getUserId()
    {
        return $this->request->header('X-User-Id') ? (int)$this->request->header('X-User-Id')->getValue() : null;
    }

    /**
     * GET /api/client/dashboard
     */
    public function dashboard()
    {
        $userId = $this->getUserId();
        $db = \Config\Database::connect();

        $orders = $db->table('orders')
            ->where('user_id', $userId)
            ->orderBy('id', 'DESC')
            ->get()
            ->getResultArray();

        $totalOrders = count($orders);
        $activeOrders = 0;
        $completedOrders = 0;
        $totalLinksDelivered = 0;

        foreach ($orders as $order) {
            if ($order['status'] === 'in_progress') $activeOrders++;
            if ($order['status'] === 'completed') $completedOrders++;

            $delivered = $db->table('order_phases')
                ->where('order_id', $order['id'])
                ->selectSum('delivered_links')
                ->get()
                ->getRowArray();
            $totalLinksDelivered += (int)($delivered['delivered_links'] ?? 0);
        }

        // Get single master reports for client
        $reports = $db->table('order_reports')
            ->join('orders', 'orders.id = order_reports.order_id')
            ->where('orders.user_id', $userId)
            ->where('order_reports.is_visible', true)
            ->select('order_reports.*, orders.package_name, orders.invoice_no')
            ->get()
            ->getResultArray();

        return $this->respond([
            'success' => true,
            'stats' => [
                'total_orders'          => $totalOrders,
                'active_campaigns'      => $activeOrders,
                'completed_campaigns'   => $completedOrders,
                'total_links_delivered' => $totalLinksDelivered,
            ],
            'recent_orders' => array_slice($orders, 0, 5),
            'reports'       => $reports,
        ]);
    }

    /**
     * GET /api/client/orders
     * POST /api/client/orders
     */
    public function orders()
    {
        $userId = $this->getUserId();
        $db = \Config\Database::connect();

        if ($this->request->getMethod() === 'get') {
            $orders = $db->table('orders')
                ->where('user_id', $userId)
                ->orderBy('id', 'DESC')
                ->get()
                ->getResultArray();

            foreach ($orders as &$order) {
                $order['phases'] = $db->table('order_phases')
                    ->where('order_id', $order['id'])
                    ->orderBy('phase_number', 'ASC')
                    ->get()
                    ->getResultArray();

                $order['report'] = $db->table('order_reports')
                    ->where('order_id', $order['id'])
                    ->where('is_visible', true)
                    ->get()
                    ->getRowArray();
            }

            return $this->respond(['success' => true, 'orders' => $orders]);
        }

        // POST: Place New Order
        $rules = [
            'package_id'  => 'required|is_natural_no_zero',
            'target_url'  => 'required|valid_url',
            'anchor_text' => 'required|min_length[2]|max_length[500]',
        ];

        if (!$this->validate($rules)) {
            return $this->failValidationErrors($this->validator->getErrors());
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $packageId = (int)$input['package_id'];

        $package = $db->table('packages')->where('id', $packageId)->get()->getRowArray();
        if (!$package) {
            return $this->failNotFound('Selected authority package does not exist.');
        }

        // Section 4.7: Auto-generated Invoice Number (INV-YYYYMMDD-XXX)
        $invoiceNo = 'INV-' . date('Ymd') . '-' . rand(100, 999);

        $orderData = [
            'user_id'          => $userId,
            'package_id'       => $packageId,
            'package_name'     => $package['name'],
            'invoice_no'       => $invoiceNo,
            'amount'           => $package['price_usd'],
            'target_url'       => trim(esc($input['target_url'])),
            'anchor_text'      => trim(esc($input['anchor_text'])),
            'special_notes'    => isset($input['special_notes']) ? trim(esc($input['special_notes'])) : null,
            'business_name'    => isset($input['business_name']) ? trim(esc($input['business_name'])) : null,
            'business_address' => isset($input['business_address']) ? trim(esc($input['business_address'])) : null,
            'business_phone'   => isset($input['business_phone']) ? trim(esc($input['business_phone'])) : null,
            'business_email'   => isset($input['business_email']) ? trim(esc($input['business_email'])) : null,
            'business_category'=> isset($input['business_category']) ? trim(esc($input['business_category'])) : null,
            'business_photos_link' => isset($input['business_photos_link']) ? trim(esc($input['business_photos_link'])) : null,
            'target_country'   => isset($input['target_country']) ? trim(esc($input['target_country'])) : null,
            'short_description'=> isset($input['short_description']) ? trim(esc($input['short_description'])) : null,
            'short_description_200'=> isset($input['short_description_200']) ? trim(esc($input['short_description_200'])) : null,
            'status'           => 'pending_payment',
            'total_phases'     => $package['delivery_phases'],
            'completed_phases' => 0,
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ];

        $db->table('orders')->insert($orderData);
        $orderId = $db->insertID();

        // Section 4.9: Order phases auto-created in DB with Week labels
        $packagePhases = $db->table('package_phases')
            ->where('package_id', $packageId)
            ->orderBy('phase_number', 'ASC')
            ->get()
            ->getResultArray();

        $phaseDays = round($package['duration_days'] / max(1, $package['delivery_phases']));

        foreach ($packagePhases as $idx => $pPhase) {
            $dueDate = date('Y-m-d', strtotime('+' . (($idx + 1) * $phaseDays) . ' days'));
            $db->table('order_phases')->insert([
                'order_id'              => $orderId,
                'phase_number'          => $pPhase['phase_number'],
                'week_label'            => $pPhase['week_label'],
                'expected_links'        => $pPhase['expected_links'],
                'delivered_links'       => 0,
                'status'                => 'pending',
                'due_date'              => $dueDate,
                'notification_sent'     => false,
                'links_delivered_count' => 0,
            ]);
        }

        // Section 4.10: Payment request entry created
        $db->table('payment_requests')->insert([
            'order_id'       => $orderId,
            'user_id'        => $userId,
            'transaction_id' => 'PENDING-' . $invoiceNo,
            'status'         => 'pending',
            'created_at'     => date('Y-m-d H:i:s'),
        ]);

        // Section 8: Single Master Report Entry (One Order = One URL)
        $db->table('order_reports')->insert([
            'order_id'        => $orderId,
            'spreadsheet_url' => '',
            'title'           => $package['name'] . ' Master Delivery Report',
            'description'     => 'Real-time Google Sheet tracking for ' . $invoiceNo,
            'total_links'     => 0,
            'is_visible'      => false,
            'created_at'      => date('Y-m-d H:i:s'),
        ]);

        // Activity log
        $db->table('activity_logs')->insert([
            'user_id'     => $userId,
            'role'        => 'client',
            'action'      => 'ORDER_CREATED',
            'description' => "Order #{$invoiceNo} created for package '{$package['name']}' ($" . number_format($package['price_usd'], 2) . ")",
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->respondCreated([
            'success'    => true,
            'message'    => 'Order placed successfully. Please complete wire payment.',
            'order_id'   => $orderId,
            'invoice_no' => $invoiceNo,
            'amount'     => $package['price_usd'],
        ]);
    }

    /**
     * PUT /api/client/orders/{id}
     */
    public function updateOrderDetails($id = null)
    {
        $userId = $this->getUserId();
        $db = \Config\Database::connect();

        $order = $db->table('orders')
            ->where('id', $id)
            ->where('user_id', $userId)
            ->get()
            ->getRowArray();

        if (!$order) {
            return $this->failNotFound('Order not found or unauthorized access.');
        }

        $input = $this->request->getJSON(true) ?: $this->request->getRawInput();
        
        $updateData = [
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Process fields
        $fields = [
            'business_name', 'business_address', 'business_phone', 'business_email',
            'business_category', 'business_photos_link', 'target_country',
            'short_description', 'short_description_200', 'target_url', 'anchor_text', 'special_notes'
        ];

        foreach ($fields as $f) {
            if (isset($input[$f])) {
                $updateData[$f] = trim(esc($input[$f]));
            }
        }

        $db->table('orders')->where('id', $id)->update($updateData);

        // Add activity log
        $db->table('activity_logs')->insert([
            'user_id'     => $userId,
            'role'        => 'client',
            'action'      => 'ORDER_UPDATED',
            'description' => "Order details updated by client for Order ID {$id}",
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->respond([
            'success' => true,
            'message' => 'Order details updated successfully.'
        ]);
    }

    /**
     * GET /api/client/orders/{id}
     */
    public function orderDetail($id = null)
    {
        $userId = $this->getUserId();
        $db = \Config\Database::connect();

        $order = $db->table('orders')
            ->where('id', $id)
            ->where('user_id', $userId)
            ->get()
            ->getRowArray();

        if (!$order) {
            return $this->failNotFound('Order not found or unauthorized access.');
        }

        $order['phases'] = $db->table('order_phases')
            ->where('order_id', $id)
            ->orderBy('phase_number', 'ASC')
            ->get()
            ->getResultArray();

        $order['payment'] = $db->table('payment_requests')
            ->where('order_id', $id)
            ->get()
            ->getRowArray();

        // Section 8: Master Report URL (ONE per order)
        $order['report'] = $db->table('order_reports')
            ->where('order_id', $id)
            ->where('is_visible', true)
            ->get()
            ->getRowArray();

        // Section 7: Bank Details (shown strictly inside client portal after login)
        $bankSettings = $db->table('settings')
            ->where('group_name', 'bank')
            ->get()
            ->getResultArray();

        $bankDetails = [];
        foreach ($bankSettings as $setting) {
            $bankDetails[$setting['key']] = $setting['value'];
        }

        return $this->respond([
            'success'      => true,
            'order'        => $order,
            'bank_details' => $bankDetails,
        ]);
    }

    /**
     * POST /api/client/payments/upload/{id}
     */
    public function uploadPaymentProof($id = null)
    {
        $userId = $this->getUserId();
        $db = \Config\Database::connect();

        $order = $db->table('orders')
            ->where('id', $id)
            ->where('user_id', $userId)
            ->get()
            ->getRowArray();

        if (!$order) {
            return $this->failNotFound('Order not found.');
        }

        $transactionId = trim($this->request->getPost('transaction_id') ?? '');
        if (empty($transactionId)) {
            return $this->fail('Transaction / Wire Reference ID is required.', 400);
        }

        // Section 13: File upload validation (JPG, PNG, PDF, max 5MB)
        $receiptFile = $this->request->getFile('receipt');
        $storedFilename = null;

        if ($receiptFile && $receiptFile->isValid() && !$receiptFile->hasMoved()) {
            if ($receiptFile->getSize() > 5 * 1024 * 1024) {
                return $this->fail('File exceeds maximum 5MB size limit.', 400);
            }

            $allowedMimes = ['image/jpeg', 'image/png', 'application/pdf'];
            $allowedExts = ['jpeg', 'jpg', 'png', 'pdf'];
            $clientExt = strtolower($receiptFile->getClientExtension());
            if (!in_array($receiptFile->getMimeType(), $allowedMimes) || !in_array($clientExt, $allowedExts)) {
                return $this->fail('Invalid file type. Only JPG, PNG, and PDF receipts are permitted.', 400);
            }

            $uploadPath = WRITEPATH . 'uploads/receipts/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            $storedFilename = $receiptFile->getRandomName();
            $receiptFile->move($uploadPath, $storedFilename);
        }

        // Update payment request
        $db->table('payment_requests')
            ->where('order_id', $id)
            ->update([
                'transaction_id'   => esc($transactionId),
                'receipt_path'     => $storedFilename ? 'uploads/receipts/' . $storedFilename : null,
                'receipt_filename' => $receiptFile ? $receiptFile->getClientName() : null,
                'status'           => 'pending',
                'payment_date'     => date('Y-m-d'),
                'created_at'       => date('Y-m-d H:i:s'),
            ]);

        // Update order status
        $db->table('orders')
            ->where('id', $id)
            ->update([
                'status'     => 'payment_under_review',
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

        // Activity log
        $db->table('activity_logs')->insert([
            'user_id'     => $userId,
            'role'        => 'client',
            'action'      => 'PAYMENT_PROOF_UPLOADED',
            'description' => "Payment proof uploaded for order #{$order['invoice_no']} (Tx: {$transactionId})",
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->respond([
            'success' => true,
            'message' => 'Payment receipt uploaded successfully. Admin review is underway.',
        ]);
    }

    /**
     * GET /api/client/reports/{order_id}
     */
    public function orderReport($orderId = null)
    {
        $userId = $this->getUserId();
        $db = \Config\Database::connect();

        $report = $db->table('order_reports')
            ->join('orders', 'orders.id = order_reports.order_id')
            ->where('order_reports.order_id', $orderId)
            ->where('orders.user_id', $userId)
            ->where('order_reports.is_visible', true)
            ->select('order_reports.*, orders.invoice_no, orders.package_name, orders.status as order_status')
            ->get()
            ->getRowArray();

        if (!$report) {
            return $this->failNotFound('Master report not yet available or awaiting payment approval.');
        }

        return $this->respond(['success' => true, 'report' => $report]);
    }

    /**
     * GET /api/client/profile
     * PUT /api/client/profile
     */
    public function getProfile()
    {
        $userId = $this->getUserId();
        $db = \Config\Database::connect();
        $user = $db->table('users')->where('id', $userId)->get()->getRowArray();
        unset($user['password_hash']);
        return $this->respond(['success' => true, 'user' => $user]);
    }

    public function updateProfile()
    {
        $userId = $this->getUserId();
        $input = $this->request->getJSON(true) ?: $this->request->getRawInput();
        $db = \Config\Database::connect();

        $updateData = [
            'name'       => trim(esc($input['name'] ?? '')),
            'company'    => trim(esc($input['company'] ?? '')),
            'phone'      => trim(esc($input['phone'] ?? '')),
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        $db->table('users')->where('id', $userId)->update($updateData);

        return $this->respond(['success' => true, 'message' => 'Profile updated successfully']);
    }

    /**
     * GET /api/client/reports
     */
    public function allReports()
    {
        $userId = $this->getUserId();
        $db = \Config\Database::connect();
        $reports = $db->table('order_reports')
            ->join('orders', 'orders.id = order_reports.order_id')
            ->where('orders.user_id', $userId)
            ->where('order_reports.is_visible', true)
            ->select('order_reports.*, orders.invoice_no, orders.package_name, orders.status as order_status')
            ->get()
            ->getResultArray();
        return $this->respond(['success' => true, 'reports' => $reports]);
    }

    /**
     * GET /api/client/payments
     */
    public function payments()
    {
        $userId = $this->getUserId();
        $db = \Config\Database::connect();
        $payments = $db->table('payment_requests')
            ->join('orders', 'orders.id = payment_requests.order_id')
            ->where('payment_requests.user_id', $userId)
            ->select('payment_requests.*, orders.invoice_no, orders.package_name, orders.amount')
            ->orderBy('payment_requests.id', 'DESC')
            ->get()
            ->getResultArray();
        return $this->respond(['success' => true, 'payments' => $payments]);
    }

    /**
     * PUT /api/client/profile/password
     */
    public function changePassword()
    {
        $userId = $this->getUserId();
        $input = $this->request->getJSON(true) ?: $this->request->getRawInput();
        $db = \Config\Database::connect();
        
        $currentPassword = $input['current_password'] ?? '';
        $newPassword = $input['new_password'] ?? '';
        
        $user = $db->table('users')->where('id', $userId)->get()->getRowArray();
        if (!$user || !password_verify($currentPassword, $user['password_hash'])) {
            return $this->fail('Current password is incorrect.', 400);
        }
        
        if (strlen($newPassword) < 8) {
            return $this->fail('New password must be at least 8 characters long.', 400);
        }
        
        $db->table('users')->where('id', $userId)->update([
            'password_hash' => password_hash($newPassword, PASSWORD_DEFAULT),
            'updated_at' => date('Y-m-d H:i:s')
        ]);
        
        return $this->respond(['success' => true, 'message' => 'Password changed successfully']);
    }

}
