<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class PublicController extends ResourceController
{
    protected $format = 'json';

    public function options()
    {
        $allowedOrigin = getenv('CORS_ALLOWED_ORIGIN') ?: '*';
        return $this->response
            ->setHeader('Access-Control-Allow-Origin', $allowedOrigin)
            ->setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
            ->setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-CSRF-TOKEN')
            ->setHeader('Access-Control-Allow-Credentials', 'true')
            ->setStatusCode(200);
    }

    private function attachServiceMixAndFeatures(&$pkg) {
        $pkg['totalLinks'] = $pkg['total_links'] ?? 0;
        $pkg['durationDays'] = $pkg['duration_days'] ?? 0;
        $pkg['deliveryPhases'] = $pkg['delivery_phases'] ?? 0;
        $pkg['priceUsd'] = $pkg['price_usd'] ?? 0;
        $pkg['isActive'] = $pkg['is_active'] === 't' || $pkg['is_active'] === true || $pkg['is_active'] == 1;
        $pkg['isFeatured'] = $pkg['is_featured'] === 't' || $pkg['is_featured'] === true || $pkg['is_featured'] == 1;

        if ($pkg['slug'] === 'starter-authority') {
            $pkg['description'] = 'A balanced baseline backlink portfolio designed to establish trust metrics with search engines without triggering algorithmic velocity filters.';
            $pkg['serviceMix'] = [
                'contentPublishing' => 2, 'haBacklinks' => 3, 'haTierText' => 'DR 30-50',
                'profileBacklinks' => 30, 'profileTierText' => 'DA 40+', 'web2Backlinks' => 15
            ];
            $pkg['features'] = [
                '2 Content Publishing placements', '3 High Authority Backlinks (DR 30-50)',
                '30 High DA Authority Links (DA 40+)', '15 High Quality Website Links',
                'Natural anchor text ratio optimization', 'Spread across 4 distinct delivery phases',
                'Phase-by-phase Google Sheet live reports', 'No guest posts — 100% written & published'
            ];
        } else if ($pkg['slug'] === 'growth-authority') {
            $pkg['description'] = 'Strategic link blend combining editorial content publishing, curated niche edits on aged articles, and high domain rating backlinks to push page-one rankings.';
            $pkg['serviceMix'] = [
                'contentPublishing' => 5, 'haBacklinks' => 8, 'haTierText' => 'DR 40-60',
                'nicheEdits' => 5, 'profileBacklinks' => 50, 'profileTierText' => 'DA 40+', 'web2Backlinks' => 25
            ];
            $pkg['features'] = [
                '5 Content Publishing placements', '8 High Authority Backlinks (DR 40-60)',
                '5 Niche Edit Backlinks', '50 High DA Authority Links (DA 40+)',
                '25 High Quality Website Links', '6 Weekly delivery phases over 45 days',
                'Dedicated Google Sheet per phase', 'Drip-feed indexing strategy & report tracking'
            ];
        } else if ($pkg['slug'] === 'professional-authority') {
            $pkg['description'] = 'Accelerated authority acquisition featuring DR 50-70 authority links, 10 niche insertions, and 10 bespoke articles crafted by native industry specialists.';
            $pkg['serviceMix'] = [
                'contentPublishing' => 10, 'haBacklinks' => 20, 'haTierText' => 'DR 50-70',
                'nicheEdits' => 10, 'profileBacklinks' => 75, 'profileTierText' => 'DA 50+', 'web2Backlinks' => 40
            ];
            $pkg['features'] = [
                '10 Content Publishing placements', '20 High Authority Backlinks (DR 50-70)',
                '10 Niche Edit Backlinks', '75 High DA Authority Links (DA 50+)',
                '40 High Quality Website Links', '8 Delivery phases over 60 days',
                'Live Google Sheet updates with DR/DA verification', 'Dedicated account manager review'
            ];
        } else if ($pkg['slug'] === 'business-authority') {
            $pkg['description'] = 'Designed for enterprise brands, national lead generation, and competitive e-commerce requiring national press exposure paired with DR 60-80 contextual backlinks.';
            $pkg['serviceMix'] = [
                'contentPublishing' => 20, 'haBacklinks' => 35, 'haTierText' => 'DR 60-80',
                'nicheEdits' => 20, 'profileBacklinks' => 100, 'profileTierText' => 'DA 50+', 'web2Backlinks' => 50, 'pressRelease' => 5
            ];
            $pkg['features'] = [
                '20 Content Publishing placements', '35 High Authority Backlinks (DR 60-80)',
                '20 Niche Edit Backlinks', '100 High DA Authority Links (DA 50+)',
                '50 High Quality Website Links', '5 Press Release Distribution',
                '12 Scheduled delivery phases (90 days)', 'Live Google Sheet with real-time indexing status'
            ];
        } else if ($pkg['slug'] === 'enterprise-authority') {
            $pkg['description'] = 'Maximum velocity authority infrastructure combining Digital PR media mentions, 15 national wire releases, 40 published articles, and 60 top-tier DR 70+ links.';
            $pkg['serviceMix'] = [
                'contentPublishing' => 40, 'haBacklinks' => 60, 'haTierText' => 'DR 70+',
                'nicheEdits' => 40, 'profileBacklinks' => 200, 'profileTierText' => 'DA 60+', 'web2Backlinks' => 100,
                'pressRelease' => 15, 'digitalPr' => 10
            ];
            $pkg['features'] = [
                '40 Content Publishing placements', '60 High Authority Backlinks (DR 70+)',
                '40 Niche Edit Backlinks', '200 High DA Authority Links (DA 60+)',
                '100 High Quality Website Links', '15 Press Release Distribution',
                '10 Digital PR Mentions', '16 Scheduled phases with milestone delivery checkpoints',
                'Google Sheets master dashboard with live link monitoring'
            ];
        } else {
            $pkg['description'] = '';
            $pkg['serviceMix'] = [
                'contentPublishing' => 0, 'haBacklinks' => 0, 'haTierText' => '',
                'profileBacklinks' => 0, 'profileTierText' => '', 'web2Backlinks' => 0
            ];
            $pkg['features'] = [];
        }
    }

    /**
     * GET /api/packages
     */
    public function getPackages()
    {
        $db = \Config\Database::connect();
        $packages = $db->table('packages')
            ->where('is_active', true)
            ->orderBy('display_order', 'ASC')
            ->get()
            ->getResultArray();

        foreach ($packages as &$pkg) {
            $pkg['items'] = $db->table('package_items')
                ->where('package_id', $pkg['id'])
                ->get()
                ->getResultArray();

            $pkg['phases'] = $db->table('package_phases')
                ->where('package_id', $pkg['id'])
                ->orderBy('phase_number', 'ASC')
                ->get()
                ->getResultArray();
            
            $this->attachServiceMixAndFeatures($pkg);
        }

        return $this->respond($packages);
    }

    /**
     * GET /api/packages/{slug}
     */
    public function getPackageBySlug($slug = null)
    {
        $db = \Config\Database::connect();
        $package = $db->table('packages')->where('slug', $slug)->get()->getRowArray();

        if (!$package) {
            return $this->failNotFound('Package not found.');
        }

        $package['items'] = $db->table('package_items')->where('package_id', $package['id'])->get()->getResultArray();
        $package['phases'] = $db->table('package_phases')->where('package_id', $package['id'])->orderBy('phase_number', 'ASC')->get()->getResultArray();
        $this->attachServiceMixAndFeatures($package);

        return $this->respond($package);
    }

    /**
     * GET /api/samples
     */
    public function getSamples()
    {
        $db = \Config\Database::connect();
        $samples = $db->table('sample_links')
            ->where('is_active', true)
            ->orderBy('display_order', 'ASC')
            ->get()
            ->getResultArray();

        return $this->respond($samples);
    }

    /**
     * GET /api/notifications/live
     */
    public function getLiveNotifications()
    {
        $db = \Config\Database::connect();
        $notifications = $db->table('order_notifications')
            ->where('is_active', true)
            ->orderBy('id', 'ASC')
            ->get()
            ->getResultArray();

        return $this->respond($notifications);
    }

    /**
     * POST /api/contact
     */
    public function submitContact()
    {
        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $name = trim(esc($input['name'] ?? ''));
        $email = strtolower(trim(esc($input['email'] ?? '')));
        $message = trim(esc($input['message'] ?? ''));

        if (empty($name) || empty($email) || empty($message)) {
            return $this->fail('Name, email, and inquiry message are required.', 400);
        }

        $db = \Config\Database::connect();
        $db->table('activity_logs')->insert([
            'role'        => 'visitor',
            'action'      => 'CONTACT_INQUIRY',
            'description' => "Contact inquiry received from {$name} ({$email})",
            'ip_address'  => $this->request->getIPAddress(),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->respond(['success' => true, 'message' => 'Thank you! Your message has been sent.']);
    }
}
