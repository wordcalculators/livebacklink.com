<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class JwtAdminAuth extends JwtAuth
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $res = parent::before($request, $arguments);
        if ($res instanceof ResponseInterface) {
            return $res;
        }

        $role = $request->header('X-User-Role') ? $request->header('X-User-Role')->getValue() : null;

        if ($role !== 'admin') {
            $response = service('response');
            return $response->setJSON([
                'status' => 403,
                'error'  => 'Access Denied: Administrative privileges required.'
            ])->setStatusCode(403);
        }
    }
}
