<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class JwtAuth implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $authHeader = $request->getServer('HTTP_AUTHORIZATION') ?: $request->getHeaderLine('Authorization');

        if (!$authHeader || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            $response = service('response');
            return $response->setJSON(['status' => 401, 'error' => 'Authentication token missing or invalid.'])->setStatusCode(401);
        }

        $token = $matches[1];
        $payload = $this->verifyJwt($token);

        if (!$payload) {
            $response = service('response');
            return $response->setJSON(['status' => 401, 'error' => 'Token expired or invalid signature.'])->setStatusCode(401);
        }

        // Attach user info to request headers
        $request->setHeader('X-User-Id', $payload['uid']);
        $request->setHeader('X-User-Role', $payload['role']);
        $request->setHeader('X-User-Email', $payload['mail']);
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }

    protected function verifyJwt($token)
    {
        $secret = trim((string) env('JWT_SECRET_KEY', ''));
        if ($secret === '') return false;
        $parts = explode('.', $token);
        if (count($parts) !== 3) return false;

        list($headerB64, $payloadB64, $sigB64) = $parts;
        $sig = hash_hmac('sha256', $headerB64 . '.' . $payloadB64, $secret, true);
        $expectedSig = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($sig));

        if (!hash_equals($expectedSig, $sigB64)) return false;

        $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $payloadB64)), true);
        if (!$payload || !isset($payload['exp']) || $payload['exp'] < time()) return false;

        return $payload;
    }
}
